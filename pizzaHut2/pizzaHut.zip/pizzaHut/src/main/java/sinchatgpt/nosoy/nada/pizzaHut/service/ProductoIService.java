package sinchatgpt.nosoy.nada.pizzaHut.service;

import sinchatgpt.nosoy.nada.pizzaHut.dto.ModeloDataAutocomplet;
import sinchatgpt.nosoy.nada.pizzaHut.model.Producto;

import java.util.List;

public interface ProductoIService {
    Producto save(Producto producto);
    List<Producto> findAll();
    Producto update(Producto producto);
    void delete(Long id);
    Producto findById(Long id);
    List<ModeloDataAutocomplet> listAutoCompletProducto(String nombre);
    public List<ModeloDataAutocomplet> listAutoCompletProducto();
}

