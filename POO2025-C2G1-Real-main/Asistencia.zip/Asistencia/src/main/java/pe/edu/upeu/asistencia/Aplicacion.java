package pe.edu.upeu.asistencia;

public class Aplicacion {
    public static void main(String[] args) {
        System.out.println("Iniciando Aplicacion DMP");
        AsistenciaApplication.main(args);
    }
}
