package pe.edu.upeu.asistencia.control;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import pe.edu.upeu.asistencia.enums.Carrera;
import pe.edu.upeu.asistencia.enums.TipoParticipante;
import pe.edu.upeu.asistencia.modelo.Participante;
import pe.edu.upeu.asistencia.servicio.ParticipanteServicioI;

@Controller
public class ParticipanteController {

    @FXML
    private ComboBox<Carrera> cbxCarrera;

    @FXML
    private ComboBox<TipoParticipante> cbxTipoParticipante;

    @FXML
    private TableView<Participante> tableRegPart;
    ObservableList<Participante> participantes;

    @Autowired
    ParticipanteServicioI ps;

    TableColumn<Participante, String> dniCol , nombreCol , ApellidoCol , CarreraCol , TipoParticipanteCol;

    @FXML
    public void initialize(){
        cbxCarrera.getItems().addAll(Carrera.values());
        cbxTipoParticipante.getItems().addAll(TipoParticipante.values());

        cbxCarrera.getSelectionModel().select(4);
        Carrera carrera = cbxCarrera.getSelectionModel().getSelectedItem();
        System.out.println(carrera.name());
        definirColumnas();
        listarPartipantes();
    }

    public void definirColumnas(){

        dniCol = new TableColumn<>("DNI");
        nombreCol = new TableColumn<>("Nombre");

        tableRegPart.getColumns().addAll(dniCol, nombreCol);

    }


    public void listarPartipantes(){

        dniCol.setCellValueFactory(cellData -> cellData.getValue().getDni());

        nombreCol.setCellValueFactory(cellData -> cellData.getValue().getNombre());

        participantes = FXCollections.observableList(ps.findAll());

        tableRegPart.setItems(participantes);



    }


}
