package pe.edu.upeu.abspolimorfismo;

public class ClaseGeneral {
    public static void main(String[] args) {
        Loro l = new Loro();
        l.emitirSonido();
        l.dormir();
    }
}
