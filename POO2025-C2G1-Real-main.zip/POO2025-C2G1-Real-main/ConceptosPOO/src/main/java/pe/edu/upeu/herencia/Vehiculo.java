package pe.edu.upeu.herencia;

public class Vehiculo {
    String  marca="Ford";

    public void sonido(){
        System.out.println("Tuut...tuut!");
    }

}
