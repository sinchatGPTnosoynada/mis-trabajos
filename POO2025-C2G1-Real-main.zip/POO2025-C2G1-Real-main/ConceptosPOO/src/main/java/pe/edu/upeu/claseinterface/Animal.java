package pe.edu.upeu.claseinterface;

public interface Animal {
    void emitirSonido();
    void dormir();
}
