package pe.edu.upeu.polimorfismo;

public class ClaseGeneral {
    public static void main(String[] args) {
        Loro l = new Loro();
        l.emitirSonido();
    }
}
