package pe.edu.upeu.polimorfismo;

public class Loro extends Animal{

    @Override
    public void emitirSonido(){
        System.out.println("Hola, como estas ....parece que" +
                " te estas durmiendo!");
    }
}
