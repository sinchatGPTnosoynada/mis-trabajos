package pe.edu.upeu.polimorfismo;

public class Animal {
    public void emitirSonido(){
        System.out.println("El animal hace un sonido propio!");
    }
}
