package pe.edu.upeu.asistencia;

public class aplication {

    public static void main(String[] args) {

        AsistenciaApplication.main(args);

    }

}
